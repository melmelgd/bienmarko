<?php
/**
 * head.php
 * -----------------------------------------------------------------------
 * Opens the HTML document: <head> plus the start of <body> and the outer
 * .app-shell wrapper. Every page sets $page_title before requiring this
 * file. Paired with foot.php, which closes everything opened here.
 * -----------------------------------------------------------------------
 */
$page_title = $page_title ?? 'Admin Dashboard';
require_once __DIR__ . '/../../includes/site-settings.php';
require_once __DIR__ . '/../../includes/db.php';
require_once __DIR__ . '/backup-data.php';
backup_lazy_trigger(); // scheduled backup fallback (runs after the page is sent, only when due)
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo htmlspecialchars($page_title, ENT_QUOTES, 'UTF-8'); ?> · <?php echo bienmarko_site_h(bienmarko_site_brand()['short']); ?> Admin</title>
<link rel="icon" href="../logo/palm-tree.png">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600&family=Montserrat:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="app-shell">
