<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

define('SITE_NAME', 'BienMarko');
define('SITE_TAGLINE', "Bien Marko's Pension House");

/* ------------------------------------------------------------------
   Additive migration: guests.avatar_filename. Safe to run on every
   request (same pattern admin/bookings.php uses for its own columns)
   so every page — not just profile.php — can read the column right
   away, on both fresh installs and existing deployments.
------------------------------------------------------------------ */
$pdo = bienmarko_db();
$pdo->exec("ALTER TABLE `guests` ADD COLUMN IF NOT EXISTS `avatar_filename` VARCHAR(255) NULL DEFAULT NULL AFTER `phone`");

/* ------------------------------------------------------------------
   Load the signed-in guest's display info fresh from the database on
   every page, so header.php's name/avatar always reflect the latest
   saved profile without every page having to fetch this itself.
------------------------------------------------------------------ */
$currentUser = [
    'name'   => null, // e.g. 'Shayra Walters'
    'email'  => null,
    'avatar' => null, // relative URL, or null to fall back to initials
];

if (!empty($_SESSION['auth_user_id'])) {
    $stmt = $pdo->prepare(
        'SELECT first_name, last_name, email, avatar_filename
         FROM guests WHERE id = :id LIMIT 1'
    );
    $stmt->execute(['id' => (int) $_SESSION['auth_user_id']]);
    $row = $stmt->fetch();

    if ($row) {
        $currentUser['name']  = trim($row['first_name'] . ' ' . $row['last_name']);
        $currentUser['email'] = $row['email'];
        if (!empty($row['avatar_filename'])) {
            $currentUser['avatar'] = '../admin/assets/uploads/avatars/' . rawurlencode($row['avatar_filename']);
        }
    }
}

$notifications = [];

require_once __DIR__ . '/nav-items.php';
require_once __DIR__ . '/icons.php';
require_once __DIR__ . '/ui.php';
