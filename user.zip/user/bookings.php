<?php
require_once __DIR__ . '/../includes/auth-common.php';

bienmarko_start_session();
bienmarko_require_role('user');

require_once __DIR__ . '/../includes/db.php';

require __DIR__ . '/includes/bootstrap.php';

$currentPage = 'bookings';
$pageTitle   = 'Book a Room';

// Pull guest's existing bookings (most recent first, limit 10)
$myBookings = [];
try {
    $pdo = bienmarko_db();
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `bookings` (
            `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `reference`        VARCHAR(20)  NOT NULL UNIQUE,
            `guest_id`         INT UNSIGNED NOT NULL,
            `accommodation_id` INT UNSIGNED NOT NULL,
            `check_in`         DATE         NOT NULL,
            `check_out`        DATE         NOT NULL,
            `guests_count`     SMALLINT UNSIGNED NOT NULL DEFAULT 1,
            `notes`            TEXT         NULL,
            `status`           ENUM('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'confirmed',
            `total_amount`     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            `created_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at`       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_guest`         (`guest_id`),
            KEY `idx_accommodation` (`accommodation_id`),
            KEY `idx_dates`         (`check_in`, `check_out`),
            KEY `idx_status`        (`status`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    $guestId = (int) ($_SESSION['auth_user_id'] ?? 0);
    $stmt = $pdo->prepare(
        "SELECT b.id, b.reference, b.check_in, b.check_out,
                b.guests_count, b.status, b.total_amount, b.notes,
                b.created_at, a.name AS room_name, a.type AS room_type
         FROM bookings b
         JOIN accommodations a ON a.id = b.accommodation_id
         WHERE b.guest_id = :guest_id
         ORDER BY b.created_at DESC
         LIMIT 10"
    );
    $stmt->execute(['guest_id' => $guestId]);
    $myBookings = $stmt->fetchAll();
} catch (Throwable $e) {
    $myBookings = [];
}

// Fetch all rooms for the room list panel
$allRooms = [];
try {
    $pdo = bienmarko_db();
    $roomStmt = $pdo->query(
        "SELECT id, name, type, capacity, price, status, description, amenities, image_filename
         FROM accommodations
         ORDER BY name ASC"
    );
    $allRooms = $roomStmt->fetchAll();
} catch (Throwable $e) {
    $allRooms = [];
}

$csrfToken = bienmarko_csrf_token();
$today     = date('Y-m-d');
$minOut    = date('Y-m-d', strtotime('+1 day'));

// Status badge colors
function booking_status_class(string $status): string
{
    return match ($status) {
        'confirmed'  => 'badge--green',
        'pending'    => 'badge--amber',
        'cancelled'  => 'badge--red',
        'completed'  => 'badge--blue',
        default      => 'badge--grey',
    };
}

require __DIR__ . '/includes/head.php';
?>

<style>
/* ============================================================
   bookings.php — page-scoped styles
   ============================================================ */

/* ---------- Step indicator ---------- */
.booking-steps {
  display: flex;
  align-items: center;
  gap: 0;
  margin-bottom: 28px;
  overflow-x: auto;
  padding-bottom: 4px;
}
.booking-step {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
}
.booking-step__num {
  width: 30px; height: 30px;
  border-radius: var(--radius-full);
  border: 2px solid var(--line);
  background: var(--surface-raised);
  color: var(--paper-faint);
  font-weight: 700; font-size: 13px;
  display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
  transition: background .2s, border-color .2s, color .2s;
}
.booking-step__label {
  font-size: 13px; font-weight: 600;
  color: var(--paper-faint);
  transition: color .2s;
}
.booking-step.is-active .booking-step__num {
  background: var(--ember); border-color: var(--ember);
  color: var(--ember-ink);
}
.booking-step.is-active .booking-step__label { color: var(--paper); }
.booking-step.is-done .booking-step__num {
  background: rgba(232,163,61,.18); border-color: var(--ember);
  color: var(--ember);
}
.booking-step.is-done .booking-step__label { color: var(--ember); }
.booking-step__connector {
  flex: 1; min-width: 28px; height: 2px;
  background: var(--line); border-radius: 2px;
  margin: 0 8px;
}

/* ---------- Date picker panel ---------- */
.date-panel { display: flex; flex-direction: column; gap: 20px; }

.date-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}
.date-field { display: flex; flex-direction: column; gap: 8px; }
.date-field label {
  font-size: 13px; font-weight: 600; color: var(--paper-dim);
}
.date-field input[type="date"] {
  background: var(--surface-raised);
  border: 1px solid var(--line);
  border-radius: var(--radius-sm);
  color: var(--paper);
  padding: 12px 14px;
  width: 100%;
  font-size: 15px;
  font-family: var(--font-body);
  transition: border-color .15s;
  color-scheme: dark;
}
.date-field input[type="date"]:focus {
  border-color: var(--ember); outline: none;
}

.guests-row {
  display: flex; align-items: center; gap: 16px; flex-wrap: wrap;
}
.guests-row label {
  font-size: 13px; font-weight: 600; color: var(--paper-dim);
  flex-shrink: 0;
}
.guests-stepper {
  display: flex; align-items: center; gap: 0;
  border: 1px solid var(--line); border-radius: var(--radius-sm);
  background: var(--surface-raised); overflow: hidden;
}
.guests-stepper button {
  width: 40px; height: 44px;
  background: none; border: none;
  color: var(--paper-dim); font-size: 20px;
  display: flex; align-items: center; justify-content: center;
  transition: color .15s, background .15s;
}
.guests-stepper button:hover { color: var(--paper); background: rgba(255,255,255,.05); }
.guests-stepper input {
  width: 52px; height: 44px;
  background: none; border: none;
  color: var(--paper); font-size: 15px; font-weight: 600;
  text-align: center; font-family: var(--font-body);
}
.guests-stepper input::-webkit-inner-spin-button,
.guests-stepper input::-webkit-outer-spin-button { -webkit-appearance: none; }

.night-summary {
  display: flex; align-items: center; gap: 10px;
  padding: 12px 16px;
  background: rgba(232,163,61,.1);
  border: 1px solid rgba(232,163,61,.3);
  border-radius: var(--radius-sm);
  font-size: 14px; color: var(--ember-strong);
  font-weight: 600;
}
.night-summary .icon { width: 16px; height: 16px; }

/* ---------- All Rooms panel ---------- */
.all-rooms-section { display: flex; flex-direction: column; gap: 16px; }
.all-rooms-header {
  display: flex; align-items: center; justify-content: space-between;
  flex-wrap: wrap; gap: 8px;
}
.all-rooms-header h2 { font-size: 18px; }
.all-rooms-subtitle { font-size: 13px; color: var(--paper-dim); margin-top: 2px; }

.all-rooms-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
  gap: 16px;
}

/* ---------- Room thumb card (in Step 1) ---------- */
.rthumb {
  background: var(--surface);
  border: 2px solid var(--line);
  border-radius: var(--radius-lg);
  overflow: hidden;
  display: flex; flex-direction: column;
  cursor: pointer;
  transition: border-color .2s, transform .15s, box-shadow .2s;
  position: relative;
}
.rthumb:hover {
  border-color: var(--ember);
  transform: translateY(-2px);
  box-shadow: 0 8px 24px -8px rgba(232,163,61,.25);
}
.rthumb.is-selected {
  border-color: var(--ember);
  box-shadow: 0 0 0 3px rgba(232,163,61,.2);
}
.rthumb__media {
  position: relative;
  aspect-ratio: 16/9;
  background: var(--surface-raised);
  display: flex; align-items: center; justify-content: center;
  overflow: hidden;
}
.rthumb__media img {
  width: 100%; height: 100%; object-fit: cover; display: block;
}
.rthumb__media-icon { width: 38px; height: 38px; color: var(--paper-faint); }
.rthumb__status-badge {
  position: absolute; left: 8px; top: 8px;
  border-radius: var(--radius-full);
  font-size: 10px; font-weight: 700;
  padding: 3px 8px;
  display: flex; align-items: center; gap: 4px;
  pointer-events: none;
}
.rthumb__status-badge .dot {
  width: 5px; height: 5px; border-radius: 50%; flex-shrink: 0;
}
.rstatus--available   { background: rgba(40,160,90,.9);  color: #fff; }
.rstatus--available .dot { background: #7fffa8; }
.rstatus--booked      { background: rgba(220,100,50,.9); color: #fff; }
.rstatus--booked .dot { background: #ffd080; }
.rstatus--unavailable { background: rgba(80,80,100,.9);  color: #ddd; }
.rstatus--unavailable .dot { background: #aaa; }
.rstatus--maintenance { background: rgba(160,120,20,.9); color: #fff; }
.rstatus--maintenance .dot { background: #ffe97a; }

.rthumb__cal-btn {
  position: absolute; right: 8px; top: 8px;
  background: rgba(11,13,15,.82);
  border: 1px solid rgba(255,255,255,.15);
  border-radius: var(--radius-full);
  color: var(--paper-dim);
  font-size: 11px; font-weight: 700;
  padding: 4px 10px;
  display: flex; align-items: center; gap: 5px;
  cursor: pointer;
  transition: color .15s, border-color .15s;
  pointer-events: all;
}
.rthumb__cal-btn:hover { color: var(--ember); border-color: var(--ember); }
.rthumb__cal-btn svg { width: 11px; height: 11px; flex-shrink: 0; }

.rthumb__price-badge {
  position: absolute; right: 8px; bottom: 8px;
  background: rgba(11,13,15,.85);
  border: 1px solid rgba(255,255,255,.12);
  border-radius: var(--radius-full);
  font-family: var(--font-display); font-weight: 700;
  font-size: 13px; color: var(--paper);
  padding: 4px 10px;
}
.rthumb__price-badge small {
  font-family: var(--font-body); font-size: 10px;
  color: var(--paper-dim); font-weight: 400;
}

.rthumb__body {
  padding: 12px 14px;
  display: flex; flex-direction: column; gap: 8px;
  flex: 1;
}
.rthumb__name { font-size: 15px; font-weight: 700; }
.rthumb__type { font-size: 12px; color: var(--paper-dim); margin-top: -4px; }
.rthumb__meta {
  display: flex; align-items: center; gap: 5px;
  font-size: 12px; color: var(--paper-dim);
}
.rthumb__amenities { display: flex; flex-wrap: wrap; gap: 4px; }
.rthumb__tag {
  font-size: 10px; font-weight: 600;
  background: var(--surface-raised); border: 1px solid var(--line);
  border-radius: var(--radius-full); padding: 2px 7px;
  color: var(--paper-dim);
}
.rthumb__tag--more { color: var(--ember); border-color: rgba(232,163,61,.4); }

.rthumb__footer {
  padding: 10px 14px;
  border-top: 1px solid var(--line);
  display: flex; align-items: center; justify-content: space-between;
  gap: 8px;
}
.rthumb__select-btn {
  display: inline-flex; align-items: center; gap: 5px;
  padding: 7px 13px;
  background: var(--ember); color: var(--ember-ink);
  border-radius: var(--radius-full);
  font-weight: 700; font-size: 12px;
  border: none; cursor: pointer;
  transition: background .15s;
}
.rthumb__select-btn:hover { background: var(--ember-strong); }
.rthumb__unavail-label {
  font-size: 11px; color: var(--paper-faint); font-weight: 600;
  padding: 7px 0;
}

/* ---------- Room grid in Step 2 ---------- */
.rooms-section { display: flex; flex-direction: column; gap: 20px; }
.rooms-header {
  display: flex; align-items: center; justify-content: space-between;
  flex-wrap: wrap; gap: 12px;
}
.rooms-header h2 { font-size: 19px; }
.rooms-meta { font-size: 13.5px; color: var(--paper-dim); }
.rooms-meta strong { color: var(--paper); }

.rooms-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 18px;
}

.room-card {
  background: var(--surface);
  border: 1px solid var(--line);
  border-radius: var(--radius-lg);
  overflow: hidden;
  display: flex; flex-direction: column;
  transition: border-color .2s, transform .15s;
  position: relative;
}
.room-card:hover { border-color: var(--ember-strong); transform: translateY(-2px); }
.room-card.is-occupied { opacity: 0.6; pointer-events: none; }
.room-card.is-unavailable { opacity: 0.5; pointer-events: none; }

.room-card__media {
  position: relative;
  aspect-ratio: 16/10;
  background: var(--surface-raised);
  display: flex; align-items: center; justify-content: center;
  overflow: hidden;
}
.room-card__media img {
  width: 100%; height: 100%; object-fit: cover; display: block;
}
.room-card__media-icon { width: 44px; height: 44px; color: var(--paper-faint); }
.room-card__price-badge {
  position: absolute; right: 10px; bottom: 10px;
  background: rgba(11,13,15,.85);
  border: 1px solid rgba(255,255,255,.12);
  border-radius: var(--radius-full);
  font-family: var(--font-display); font-weight: 700;
  font-size: 14px; color: var(--paper);
  padding: 5px 12px;
}
.room-card__price-badge small {
  font-family: var(--font-body); font-size: 11px;
  color: var(--paper-dim); font-weight: 400;
}

.room-card__avail-badge {
  position: absolute; left: 10px; top: 10px;
  border-radius: var(--radius-full);
  font-size: 11px; font-weight: 700;
  padding: 4px 10px;
  display: flex; align-items: center; gap: 5px;
}
.room-card__avail-badge .dot {
  width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0;
}
.avail--available   { background: rgba(40,160,90,.9);  color: #fff; }
.avail--available .dot { background: #7fffa8; }
.avail--occupied    { background: rgba(220,100,50,.9); color: #fff; }
.avail--occupied .dot { background: #ffd080; }
.avail--unavailable { background: rgba(80,80,100,.9);  color: #ddd; }
.avail--unavailable .dot { background: #aaa; }

.room-card__body { padding: 16px; display: flex; flex-direction: column; gap: 12px; flex: 1; }
.room-card__head { display: flex; flex-direction: column; gap: 3px; }
.room-card__name { font-size: 16px; font-weight: 700; line-height: 1.3; }
.room-card__type { font-size: 12px; color: var(--paper-dim); }

.room-card__meta {
  display: flex; align-items: center; gap: 6px;
  font-size: 13px; color: var(--paper-dim);
}
.room-card__meta .icon { width: 14px; height: 14px; }

.room-card__amenities { display: flex; flex-wrap: wrap; gap: 5px; }
.room-tag {
  font-size: 11px; font-weight: 600;
  background: var(--surface-raised); border: 1px solid var(--line);
  border-radius: var(--radius-full); padding: 3px 9px;
  color: var(--paper-dim);
}
.room-tag--more { color: var(--ember); border-color: rgba(232,163,61,.4); }

.room-card__desc {
  font-size: 13px; color: var(--paper-dim); line-height: 1.5;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;
  overflow: hidden;
}

.room-card__footer {
  padding: 12px 16px;
  border-top: 1px solid var(--line);
  display: flex; align-items: center; justify-content: space-between;
  gap: 10px;
}
.room-card__total {
  font-family: var(--font-display); font-weight: 700; font-size: 17px;
  color: var(--paper);
}
.room-card__total small {
  font-family: var(--font-body); font-size: 11px;
  color: var(--paper-dim); font-weight: 400;
}

.btn-book {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 9px 16px;
  background: var(--ember); color: var(--ember-ink);
  border-radius: var(--radius-full);
  font-weight: 700; font-size: 13.5px;
  border: none;
  transition: background .15s, transform .1s;
  cursor: pointer;
}
.btn-book:hover { background: var(--ember-strong); }
.btn-book:active { transform: scale(.97); }
.btn-book .icon { width: 14px; height: 14px; }

/* ---------- Skeleton loader ---------- */
.rooms-skeleton { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px,1fr)); gap: 18px; }
.skeleton-card {
  background: var(--surface); border: 1px solid var(--line);
  border-radius: var(--radius-lg); overflow: hidden;
}
.skeleton-media {
  aspect-ratio: 16/10;
  background: linear-gradient(90deg, var(--surface-raised) 25%, var(--line) 50%, var(--surface-raised) 75%);
  background-size: 200% 100%;
  animation: shimmer 1.4s infinite;
}
.skeleton-body { padding: 16px; display: flex; flex-direction: column; gap: 10px; }
.skeleton-line {
  height: 14px; border-radius: 6px;
  background: linear-gradient(90deg, var(--surface-raised) 25%, var(--line) 50%, var(--surface-raised) 75%);
  background-size: 200% 100%;
  animation: shimmer 1.4s infinite;
}
.skeleton-line--short { width: 55%; }
.skeleton-line--medium { width: 75%; }
@keyframes shimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}

/* ---------- No-results ---------- */
.rooms-empty {
  text-align: center; padding: 48px 24px; color: var(--paper-dim);
}
.rooms-empty__icon {
  width: 56px; height: 56px; border-radius: var(--radius-full);
  background: rgba(232,163,61,.1); border: 1px solid rgba(232,163,61,.3);
  display: flex; align-items: center; justify-content: center;
  margin: 0 auto 16px;
}
.rooms-empty__icon .icon { width: 26px; height: 26px; }
.rooms-empty h3 { font-size: 17px; margin-bottom: 6px; }
.rooms-empty p  { font-size: 14px; max-width: 340px; margin: 0 auto; }

/* ---------- Booking confirm modal ---------- */
.bk-modal {
  border: 1px solid var(--line);
  border-radius: var(--radius-lg);
  background: var(--surface-raised);
  color: var(--paper);
  padding: 0;
  width: min(94vw, 460px);
  box-shadow: 0 24px 60px -20px rgba(0,0,0,.7);
  overflow: hidden;
}
.bk-modal::backdrop { background: rgba(0,0,0,.65); backdrop-filter: blur(3px); }
.bk-modal__head {
  display: flex; align-items: center; justify-content: space-between;
  padding: 20px 20px 0;
}
.bk-modal__head h2 { font-size: 19px; }
.bk-modal__close {
  width: 32px; height: 32px; border-radius: var(--radius-full);
  background: var(--surface); border: 1px solid var(--line);
  color: var(--paper-dim); display: flex; align-items: center; justify-content: center;
  cursor: pointer;
}
.bk-modal__close .icon { width: 15px; height: 15px; }
.bk-modal__close:hover { color: var(--paper); border-color: var(--ember); }

.bk-modal__room {
  display: flex; align-items: center; gap: 14px;
  padding: 16px 20px;
  border-bottom: 1px solid var(--line);
}
.bk-modal__room-img {
  width: 72px; height: 56px; border-radius: var(--radius-sm);
  background: var(--surface); border: 1px solid var(--line);
  object-fit: cover; flex-shrink: 0; overflow: hidden;
  display: flex; align-items: center; justify-content: center;
}
.bk-modal__room-img img { width: 100%; height: 100%; object-fit: cover; }
.bk-modal__room-img .icon { width: 26px; height: 26px; color: var(--paper-faint); }
.bk-modal__room-name { font-size: 16px; font-weight: 700; }
.bk-modal__room-type { font-size: 12px; color: var(--paper-dim); margin-top: 2px; }

.bk-modal__details { padding: 16px 20px; display: flex; flex-direction: column; gap: 10px; }
.bk-detail-row {
  display: flex; align-items: flex-start; justify-content: space-between;
  gap: 12px; font-size: 14px;
}
.bk-detail-row__label { color: var(--paper-dim); flex-shrink: 0; }
.bk-detail-row__value { font-weight: 600; text-align: right; }
.bk-detail-divider { height: 1px; background: var(--line); margin: 4px 0; }
.bk-detail-row--total .bk-detail-row__label { font-weight: 700; color: var(--paper); }
.bk-detail-row--total .bk-detail-row__value {
  font-family: var(--font-display); font-size: 18px; color: var(--ember-strong);
}

.bk-modal__notes-field { padding: 0 20px; }
.bk-modal__notes-field label { font-size: 13px; font-weight: 600; color: var(--paper-dim); display: block; margin-bottom: 6px; }
.bk-modal__notes-field textarea {
  width: 100%; resize: vertical; min-height: 70px;
  background: var(--surface); border: 1px solid var(--line);
  border-radius: var(--radius-sm); color: var(--paper);
  padding: 10px 12px; font-family: var(--font-body); font-size: 14px;
  transition: border-color .15s;
}
.bk-modal__notes-field textarea:focus { border-color: var(--ember); outline: none; }
.bk-modal__notes-field textarea::placeholder { color: var(--paper-faint); }

.bk-modal__foot {
  display: flex; align-items: center; justify-content: space-between; gap: 10px;
  padding: 16px 20px;
  border-top: 1px solid var(--line);
}
.bk-modal__error {
  font-size: 13px; color: var(--danger);
  min-height: 1px; flex: 1;
}
.bk-modal__foot-actions { display: flex; gap: 10px; flex-shrink: 0; }

.btn--cancel {
  padding: 10px 16px;
  background: transparent; border: 1px solid var(--line);
  border-radius: var(--radius-full); color: var(--paper-dim);
  font-weight: 600; font-size: 14px; cursor: pointer;
  transition: border-color .15s, color .15s;
}
.btn--cancel:hover { border-color: var(--ember); color: var(--paper); }

/* ---------- Success screen ---------- */
.bk-success {
  display: none; flex-direction: column; align-items: center;
  text-align: center; padding: 36px 24px;
}
.bk-success.is-visible { display: flex; }
.bk-success__icon {
  width: 64px; height: 64px; border-radius: var(--radius-full);
  background: rgba(40,180,100,.18); border: 2px solid rgba(40,180,100,.4);
  display: flex; align-items: center; justify-content: center;
  margin-bottom: 16px;
}
.bk-success__icon .icon { width: 30px; height: 30px; }
.bk-success h2 { font-size: 22px; margin-bottom: 8px; }
.bk-success p { font-size: 14px; color: var(--paper-dim); line-height: 1.6; max-width: 320px; margin: 0 auto 6px; }
.bk-success__ref {
  display: inline-block; margin: 12px 0;
  background: rgba(232,163,61,.15); border: 1px solid rgba(232,163,61,.35);
  border-radius: var(--radius-sm); padding: 8px 18px;
  font-family: var(--font-display); font-size: 18px; font-weight: 700;
  color: var(--ember-strong);
  letter-spacing: .05em;
}
.bk-success__actions { display: flex; gap: 10px; margin-top: 16px; flex-wrap: wrap; justify-content: center; }

/* ---------- My Bookings list ---------- */
.bk-list { display: flex; flex-direction: column; gap: 12px; }
.bk-item {
  display: flex; align-items: flex-start; gap: 14px;
  padding: 14px 16px;
  background: var(--surface-raised); border: 1px solid var(--line);
  border-radius: var(--radius-md);
}
.bk-item__ref {
  font-family: var(--font-display); font-size: 13px; font-weight: 700;
  color: var(--ember); letter-spacing: .04em; flex-shrink: 0;
  min-width: 120px;
}
.bk-item__body { flex: 1; min-width: 0; }
.bk-item__room { font-weight: 700; font-size: 14.5px; margin-bottom: 2px; }
.bk-item__dates { font-size: 13px; color: var(--paper-dim); }
.bk-item__meta { font-size: 12px; color: var(--paper-faint); margin-top: 2px; }
.bk-item__right { display: flex; flex-direction: column; align-items: flex-end; gap: 4px; flex-shrink: 0; }
.bk-item__amount { font-family: var(--font-display); font-size: 15px; font-weight: 700; }
.badge {
  display: inline-flex; align-items: center;
  padding: 3px 9px; border-radius: var(--radius-full);
  font-size: 11px; font-weight: 700; letter-spacing: .03em;
}
.badge--green  { background: rgba(40,160,90,.2);  color: #4fd882; }
.badge--amber  { background: rgba(220,160,40,.2); color: var(--ember-strong); }
.badge--red    { background: rgba(220,80,60,.2);  color: var(--danger); }
.badge--blue   { background: rgba(80,140,220,.2); color: #86b8e8; }
.badge--grey   { background: rgba(140,140,150,.2); color: var(--paper-dim); }

/* ---------- Error state ---------- */
.api-error {
  display: flex; align-items: center; gap: 10px;
  padding: 14px 16px;
  background: rgba(220,80,60,.1); border: 1px solid rgba(220,80,60,.3);
  border-radius: var(--radius-sm); color: var(--danger); font-size: 14px;
}
.api-error .icon { width: 18px; height: 18px; flex-shrink: 0; }

/* ============================================================
   CALENDAR MODAL
   ============================================================ */
.cal-modal {
  border: 1px solid var(--line);
  border-radius: var(--radius-lg);
  background: var(--surface-raised);
  color: var(--paper);
  padding: 0;
  width: min(96vw, 520px);
  box-shadow: 0 24px 60px -20px rgba(0,0,0,.75);
  overflow: hidden;
}
.cal-modal::backdrop { background: rgba(0,0,0,.7); backdrop-filter: blur(4px); }

.cal-modal__head {
  display: flex; align-items: flex-start; justify-content: space-between;
  padding: 18px 20px 14px;
  border-bottom: 1px solid var(--line);
  gap: 12px;
}
.cal-modal__title { font-size: 17px; font-weight: 700; }
.cal-modal__subtitle { font-size: 12px; color: var(--paper-dim); margin-top: 2px; }
.cal-modal__close {
  width: 30px; height: 30px; flex-shrink: 0;
  border-radius: var(--radius-full);
  background: var(--surface); border: 1px solid var(--line);
  color: var(--paper-dim);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; margin-top: 2px;
}
.cal-modal__close:hover { color: var(--paper); border-color: var(--ember); }
.cal-modal__close svg { width: 14px; height: 14px; }

/* Legend */
.cal-legend {
  display: flex; align-items: center; gap: 14px; flex-wrap: wrap;
  padding: 10px 20px;
  border-bottom: 1px solid var(--line);
  background: var(--surface);
}
.cal-legend-item {
  display: flex; align-items: center; gap: 5px;
  font-size: 11px; color: var(--paper-dim); font-weight: 600;
}
.cal-legend-dot {
  width: 10px; height: 10px; border-radius: 3px; flex-shrink: 0;
}
.cal-legend-dot--available   { background: rgba(40,160,90,.7); }
.cal-legend-dot--booked      { background: rgba(220,80,60,.7); }
.cal-legend-dot--maintenance { background: rgba(220,160,20,.7); }
.cal-legend-dot--unavailable { background: rgba(100,100,120,.7); }

/* Month nav */
.cal-body { padding: 16px 20px 20px; }
.cal-nav {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 14px;
}
.cal-nav__btn {
  width: 32px; height: 32px;
  background: var(--surface); border: 1px solid var(--line);
  border-radius: var(--radius-full); color: var(--paper-dim);
  display: flex; align-items: center; justify-content: center;
  cursor: pointer; transition: color .15s, border-color .15s;
}
.cal-nav__btn:hover { color: var(--ember); border-color: var(--ember); }
.cal-nav__btn svg { width: 14px; height: 14px; }
.cal-nav__btn:disabled { opacity: .35; cursor: not-allowed; pointer-events: none; }
.cal-nav__label { font-size: 15px; font-weight: 700; }

/* Grid */
.cal-grid {
  display: grid;
  grid-template-columns: repeat(7, 1fr);
  gap: 3px;
}
.cal-day-header {
  text-align: center;
  font-size: 10px; font-weight: 700; letter-spacing: .06em;
  color: var(--paper-faint);
  padding-bottom: 6px;
  text-transform: uppercase;
}
.cal-day {
  aspect-ratio: 1;
  display: flex; align-items: center; justify-content: center;
  border-radius: var(--radius-sm);
  font-size: 12px; font-weight: 600;
  position: relative;
  transition: background .12s;
}
.cal-day--empty { background: transparent; }
.cal-day--today {
  color: var(--ember);
  font-weight: 800;
}
.cal-day--today::after {
  content: '';
  position: absolute; bottom: 3px; left: 50%; transform: translateX(-50%);
  width: 4px; height: 4px; border-radius: 50%;
  background: var(--ember);
}
.cal-day--past {
  color: var(--paper-faint);
  background: transparent;
}
.cal-day--available {
  background: rgba(40,160,90,.15);
  color: #5de89a;
}
.cal-day--booked {
  background: rgba(220,80,60,.2);
  color: #f08080;
  text-decoration: line-through;
}
.cal-day--maintenance {
  background: rgba(220,160,20,.2);
  color: #e8c23d;
}
.cal-day--unavailable {
  background: rgba(100,100,120,.18);
  color: var(--paper-faint);
}

/* Loading spinner in calendar */
.cal-loading {
  display: flex; align-items: center; justify-content: center;
  gap: 10px; padding: 32px 0;
  color: var(--paper-dim); font-size: 14px;
}
.cal-spinner {
  width: 20px; height: 20px;
  border: 2px solid var(--line);
  border-top-color: var(--ember);
  border-radius: 50%;
  animation: spin .7s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

/* ---------- Responsive ---------- */
@media (max-width: 600px) {
  .date-row { grid-template-columns: 1fr; }
  .booking-step__label { display: none; }
  .bk-item { flex-direction: column; gap: 8px; }
  .bk-item__right { flex-direction: row; align-items: center; }
  .all-rooms-grid { grid-template-columns: 1fr; }
  .cal-modal { width: 96vw; }
}
</style>

<main class="page" id="main-content">

    <!-- Page header -->
    <div class="page-head">
        <div class="page-head__text">
            <h1 class="page-head__title">Book a Room</h1>
            <p class="page-head__subtitle">Choose your dates to see real-time availability.</p>
        </div>
    </div>

    <!-- Step indicator -->
    <div class="booking-steps" id="bookingSteps" aria-label="Booking steps">
        <div class="booking-step is-active" id="step1Indicator">
            <span class="booking-step__num">1</span>
            <span class="booking-step__label">Select Dates</span>
        </div>
        <div class="booking-step__connector"></div>
        <div class="booking-step" id="step2Indicator">
            <span class="booking-step__num">2</span>
            <span class="booking-step__label">Choose Room</span>
        </div>
        <div class="booking-step__connector"></div>
        <div class="booking-step" id="step3Indicator">
            <span class="booking-step__num">3</span>
            <span class="booking-step__label">Confirm</span>
        </div>
    </div>

    <div class="content-grid content-grid--stack">

        <!-- ===== STEP 1: Date + Guest picker ===== -->
        <section class="panel" id="step1Panel">
            <div class="panel__head">
                <h2>When would you like to stay?</h2>
                <p class="panel__subtitle">Select your check-in and check-out dates.</p>
            </div>

            <div class="date-panel">
                <div class="date-row">
                    <div class="date-field">
                        <label for="bkCheckIn">Check-in date</label>
                        <input type="date" id="bkCheckIn"
                               min="<?php echo $today; ?>"
                               value=""
                               aria-required="true">
                    </div>
                    <div class="date-field">
                        <label for="bkCheckOut">Check-out date</label>
                        <input type="date" id="bkCheckOut"
                               min="<?php echo $minOut; ?>"
                               value=""
                               aria-required="true">
                    </div>
                </div>

                <div class="guests-row">
                    <label for="bkGuests">Number of guests</label>
                    <div class="guests-stepper">
                        <button type="button" id="guestsMinus" aria-label="Decrease guests">−</button>
                        <input type="number" id="bkGuests" value="1" min="1" max="20" readonly aria-live="polite">
                        <button type="button" id="guestsPlus"  aria-label="Increase guests">+</button>
                    </div>
                </div>

                <div id="nightSummary" style="display:none" class="night-summary">
                    <?php render_icon('calendar-check'); ?>
                    <span id="nightSummaryText"></span>
                </div>

                <div id="dateError" class="api-error" style="display:none">
                    <?php render_icon('circle-help'); ?>
                    <span id="dateErrorText"></span>
                </div>

                <button type="button" class="btn btn--primary" id="checkAvailBtn" style="align-self:flex-start">
                    <?php render_icon('bed-double'); ?> Check Availability
                </button>
            </div>
        </section>

        <!-- ===== ALL ROOMS panel (always visible in Step 1) ===== -->
        <section class="panel" id="allRoomsPanel">
            <div class="all-rooms-section">
                <div class="all-rooms-header">
                    <div>
                        <h2>All Rooms</h2>
                        <p class="all-rooms-subtitle">Click <strong>View Calendar</strong> on any room to see its booking schedule. Select dates above then click <strong>Check Availability</strong> to book.</p>
                    </div>
                    <span style="font-size:13px;color:var(--paper-dim);font-weight:600">
                        <?php echo count($allRooms); ?> room<?php echo count($allRooms) !== 1 ? 's' : ''; ?>
                    </span>
                </div>

                <?php if (empty($allRooms)): ?>
                    <?php render_empty_state(
                        'bed-double',
                        'No rooms yet',
                        'No accommodations have been added yet. Check back soon.'
                    ); ?>
                <?php else: ?>
                    <div class="all-rooms-grid" id="allRoomsGrid">
                        <?php foreach ($allRooms as $room):
                            $amenities = [];
                            if ($room['amenities']) {
                                $dec = json_decode($room['amenities'], true);
                                if (is_array($dec)) $amenities = $dec;
                            }
                            $imgBase = '../admin/assets/uploads/accommodations/';

                            // Admin-set status badge
                            $statusKey   = $room['status']; // available|booked|unavailable|maintenance
                            $statusLabel = match ($statusKey) {
                                'available'   => 'Available',
                                'booked'      => 'Booked',
                                'unavailable' => 'Unavailable',
                                'maintenance' => 'Under Maintenance',
                                default       => ucfirst($statusKey),
                            };
                            $statusClass = 'rstatus--' . ($statusKey === 'booked' ? 'booked' : $statusKey);

                            $canBook = ($statusKey === 'available' || $statusKey === 'booked');
                        ?>
                        <div class="rthumb" data-room-id="<?php echo (int)$room['id']; ?>"
                             data-room-name="<?php echo htmlspecialchars($room['name']); ?>"
                             data-room-status="<?php echo htmlspecialchars($statusKey); ?>">
                            <div class="rthumb__media">
                                <?php if (!empty($room['image_filename'])): ?>
                                    <img src="<?php echo htmlspecialchars($imgBase . $room['image_filename']); ?>"
                                         alt="<?php echo htmlspecialchars($room['name']); ?>"
                                         loading="lazy">
                                <?php else: ?>
                                    <span class="rthumb__media-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="width:100%;height:100%"><path d="M2 4v16"/><path d="M2 8h18a2 2 0 0 1 2 2v10"/><path d="M2 17h20"/><path d="M6 8v9"/></svg>
                                    </span>
                                <?php endif; ?>

                                <!-- Status badge -->
                                <span class="rthumb__status-badge <?php echo $statusClass; ?>">
                                    <span class="dot"></span>
                                    <?php echo htmlspecialchars($statusLabel); ?>
                                </span>

                                <!-- Calendar button -->
                                <button type="button" class="rthumb__cal-btn"
                                        data-cal-room-id="<?php echo (int)$room['id']; ?>"
                                        data-cal-room-name="<?php echo htmlspecialchars($room['name']); ?>"
                                        data-cal-room-type="<?php echo htmlspecialchars($room['type']); ?>"
                                        aria-label="View booking calendar for <?php echo htmlspecialchars($room['name']); ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                                    View Calendar
                                </button>

                                <!-- Price badge -->
                                <span class="rthumb__price-badge">
                                    ₱<?php echo number_format((float)$room['price'], 0); ?><small>/night</small>
                                </span>
                            </div>

                            <div class="rthumb__body">
                                <div class="rthumb__name"><?php echo htmlspecialchars($room['name']); ?></div>
                                <div class="rthumb__type"><?php echo htmlspecialchars($room['type']); ?></div>
                                <div class="rthumb__meta">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:12px;height:12px;flex-shrink:0"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                                    Up to <?php echo (int)$room['capacity']; ?> guest<?php echo (int)$room['capacity'] !== 1 ? 's' : ''; ?>
                                </div>
                                <?php if (!empty($amenities)): ?>
                                <div class="rthumb__amenities">
                                    <?php
                                    $shown = array_slice($amenities, 0, 3);
                                    $more  = count($amenities) - 3;
                                    foreach ($shown as $a): ?>
                                        <span class="rthumb__tag"><?php echo htmlspecialchars($a); ?></span>
                                    <?php endforeach;
                                    if ($more > 0): ?>
                                        <span class="rthumb__tag rthumb__tag--more">+<?php echo $more; ?> more</span>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>

                            <div class="rthumb__footer">
                                <span style="font-size:13px;color:var(--paper-dim)">
                                    ₱<?php echo number_format((float)$room['price'], 2); ?>/night
                                </span>
                                <?php if ($statusKey === 'available' || $statusKey === 'booked'): ?>
                                    <button type="button" class="rthumb__select-btn"
                                            data-select-room-id="<?php echo (int)$room['id']; ?>">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="width:11px;height:11px"><polyline points="20 6 9 17 4 12"/></svg>
                                        Select &amp; Check
                                    </button>
                                <?php else: ?>
                                    <span class="rthumb__unavail-label">Not available</span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- ===== STEP 2: Room results ===== -->
        <section class="panel" id="step2Panel" style="display:none">
            <div class="rooms-section">
                <div class="rooms-header">
                    <h2>Available Rooms</h2>
                    <span class="rooms-meta" id="roomsMeta"></span>
                </div>

                <!-- Loading skeletons -->
                <div class="rooms-skeleton" id="roomsSkeleton" style="display:none">
                    <?php for ($i = 0; $i < 3; $i++): ?>
                    <div class="skeleton-card">
                        <div class="skeleton-media"></div>
                        <div class="skeleton-body">
                            <div class="skeleton-line skeleton-line--medium"></div>
                            <div class="skeleton-line skeleton-line--short"></div>
                            <div class="skeleton-line skeleton-line--medium"></div>
                        </div>
                    </div>
                    <?php endfor; ?>
                </div>

                <!-- Error -->
                <div class="api-error" id="roomsError" style="display:none">
                    <?php render_icon('circle-help'); ?>
                    <span id="roomsErrorText">Could not load rooms. Please try again.</span>
                </div>

                <!-- Room grid (populated by JS) -->
                <div class="rooms-grid" id="roomsGrid" style="display:none"></div>

                <!-- No results -->
                <div class="rooms-empty" id="roomsEmpty" style="display:none">
                    <div class="rooms-empty__icon"><?php render_icon('bed-double'); ?></div>
                    <h3>No rooms available</h3>
                    <p>All our rooms are either occupied or unavailable for those dates. Try different dates.</p>
                </div>

                <button type="button" class="btn btn--ghost" id="changeDatesBtn" style="align-self:flex-start; margin-top:8px">
                    ← Change dates
                </button>
            </div>
        </section>

        <!-- ===== My Bookings ===== -->
        <section class="panel">
            <div class="panel__head">
                <h2>My Bookings</h2>
                <p class="panel__subtitle">Your reservation history.</p>
            </div>

            <?php if (empty($myBookings)): ?>
                <?php render_empty_state(
                    'calendar-check',
                    'No bookings yet',
                    'Select your dates above and book your first stay with us.',
                ); ?>
            <?php else: ?>
                <div class="bk-list">
                    <?php foreach ($myBookings as $bk): ?>
                        <?php
                        $checkIn   = date('M j, Y', strtotime($bk['check_in']));
                        $checkOut  = date('M j, Y', strtotime($bk['check_out']));
                        $nights    = (int) round((strtotime($bk['check_out']) - strtotime($bk['check_in'])) / 86400);
                        ?>
                        <article class="bk-item">
                            <div class="bk-item__ref"><?php echo htmlspecialchars($bk['reference']); ?></div>
                            <div class="bk-item__body">
                                <div class="bk-item__room"><?php echo htmlspecialchars($bk['room_name']); ?></div>
                                <div class="bk-item__dates">
                                    <?php echo htmlspecialchars($checkIn); ?> → <?php echo htmlspecialchars($checkOut); ?>
                                </div>
                                <div class="bk-item__meta">
                                    <?php echo $nights; ?> night<?php echo $nights !== 1 ? 's' : ''; ?> ·
                                    <?php echo (int) $bk['guests_count']; ?> guest<?php echo (int) $bk['guests_count'] !== 1 ? 's' : ''; ?>
                                </div>
                            </div>
                            <div class="bk-item__right">
                                <span class="bk-item__amount">₱<?php echo number_format((float) $bk['total_amount'], 2); ?></span>
                                <span class="badge <?php echo booking_status_class($bk['status']); ?>">
                                    <?php echo ucfirst(htmlspecialchars($bk['status'])); ?>
                                </span>
                            </div>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

    </div><!-- .content-grid -->

</main>

<!-- ===== Booking confirmation modal ===== -->
<dialog class="bk-modal" id="bkModal" aria-labelledby="bkModalTitle" aria-modal="true">

    <!-- Normal booking view -->
    <div id="bkModalContent">
        <div class="bk-modal__head">
            <h2 id="bkModalTitle">Confirm Booking</h2>
            <button type="button" class="bk-modal__close" id="bkModalClose" aria-label="Close">
                <?php render_icon('x'); ?>
            </button>
        </div>

        <!-- Room preview -->
        <div class="bk-modal__room">
            <div class="bk-modal__room-img" id="bkModalImg">
                <?php render_icon('bed-double'); ?>
            </div>
            <div>
                <div class="bk-modal__room-name" id="bkModalRoomName">Room</div>
                <div class="bk-modal__room-type" id="bkModalRoomType"></div>
            </div>
        </div>

        <!-- Booking details -->
        <div class="bk-modal__details">
            <div class="bk-detail-row">
                <span class="bk-detail-row__label">Check-in</span>
                <span class="bk-detail-row__value" id="bkDetailCheckIn">—</span>
            </div>
            <div class="bk-detail-row">
                <span class="bk-detail-row__label">Check-out</span>
                <span class="bk-detail-row__value" id="bkDetailCheckOut">—</span>
            </div>
            <div class="bk-detail-row">
                <span class="bk-detail-row__label">Duration</span>
                <span class="bk-detail-row__value" id="bkDetailNights">—</span>
            </div>
            <div class="bk-detail-row">
                <span class="bk-detail-row__label">Guests</span>
                <span class="bk-detail-row__value" id="bkDetailGuests">—</span>
            </div>
            <div class="bk-detail-row">
                <span class="bk-detail-row__label">Rate</span>
                <span class="bk-detail-row__value" id="bkDetailRate">—</span>
            </div>
            <div class="bk-detail-divider"></div>
            <div class="bk-detail-row bk-detail-row--total">
                <span class="bk-detail-row__label">Total (estimated)</span>
                <span class="bk-detail-row__value" id="bkDetailTotal">—</span>
            </div>
        </div>

        <!-- Notes field -->
        <div class="bk-modal__notes-field">
            <label for="bkNotes">Notes <span style="font-weight:400;color:var(--paper-faint)">(optional)</span></label>
            <textarea id="bkNotes" maxlength="1000"
                      placeholder="Special requests, arrival time, accessibility needs…"></textarea>
        </div>

        <!-- Footer -->
        <div class="bk-modal__foot">
            <span class="bk-modal__error" id="bkModalError" role="alert"></span>
            <div class="bk-modal__foot-actions">
                <button type="button" class="btn--cancel" id="bkModalCancelBtn">Cancel</button>
                <button type="button" class="btn-book" id="bkModalConfirmBtn">
                    <?php render_icon('send'); ?> <span id="bkConfirmLabel">Confirm Booking</span>
                </button>
            </div>
        </div>
    </div>

    <!-- Success view (replaces content after confirm) -->
    <div class="bk-success" id="bkSuccessView">
        <div class="bk-success__icon"><?php render_icon('circle-check'); ?></div>
        <h2>Booking Confirmed!</h2>
        <p>Your reservation has been placed. Please save your reference number below.</p>
        <div class="bk-success__ref" id="bkSuccessRef">BM-XXXXXXXX-XXXX</div>
        <p id="bkSuccessDetails" style="margin-top:4px"></p>
        <p style="font-size:13px;color:var(--paper-faint);margin-top:8px">
            Payment is settled upon check-in or check-out (cash or GCash).
        </p>
        <div class="bk-success__actions">
            <button type="button" class="btn btn--primary" id="bkSuccessDone">
                <?php render_icon('circle-check'); ?> Done
            </button>
        </div>
    </div>

</dialog>

<!-- ===== Calendar modal ===== -->
<dialog class="cal-modal" id="calModal" aria-labelledby="calModalTitle" aria-modal="true">
    <div class="cal-modal__head">
        <div>
            <div class="cal-modal__title" id="calModalTitle">Room Calendar</div>
            <div class="cal-modal__subtitle" id="calModalSubtitle">Loading…</div>
        </div>
        <button type="button" class="cal-modal__close" id="calModalClose" aria-label="Close calendar">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
    </div>

    <div class="cal-legend">
        <span class="cal-legend-item"><span class="cal-legend-dot cal-legend-dot--available"></span>Available</span>
        <span class="cal-legend-item"><span class="cal-legend-dot cal-legend-dot--booked"></span>Booked</span>
        <span class="cal-legend-item"><span class="cal-legend-dot cal-legend-dot--maintenance"></span>Maintenance</span>
        <span class="cal-legend-item"><span class="cal-legend-dot cal-legend-dot--unavailable"></span>Unavailable</span>
    </div>

    <div class="cal-body">
        <!-- Loading state -->
        <div class="cal-loading" id="calLoading">
            <div class="cal-spinner"></div>
            <span>Loading calendar…</span>
        </div>

        <!-- Calendar content -->
        <div id="calContent" style="display:none">
            <div class="cal-nav">
                <button type="button" class="cal-nav__btn" id="calPrevBtn" aria-label="Previous month">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <span class="cal-nav__label" id="calMonthLabel"></span>
                <button type="button" class="cal-nav__btn" id="calNextBtn" aria-label="Next month">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
            </div>
            <div class="cal-grid" id="calGrid"></div>
        </div>
    </div>
</dialog>

<!-- Hidden CSRF token for JS -->
<input type="hidden" id="csrfToken" value="<?php echo htmlspecialchars($csrfToken); ?>">
<!-- Image URL base so JS can build image paths -->
<input type="hidden" id="imgBase" value="../admin/assets/uploads/accommodations/">

<?php require __DIR__ . '/includes/support-modal.php'; ?>
<?php require __DIR__ . '/includes/foot.php'; ?>

<script>
/* =============================================================
   bookings.php — inline booking JS
   ============================================================= */

(function () {
  'use strict';

  /* ---- Cached DOM refs ---- */
  var elCheckIn  = document.getElementById('bkCheckIn');
  var elCheckOut = document.getElementById('bkCheckOut');
  var elGuests   = document.getElementById('bkGuests');
  var elCheckBtn = document.getElementById('checkAvailBtn');
  var elNightSum = document.getElementById('nightSummary');
  var elNightTxt = document.getElementById('nightSummaryText');
  var elDateErr  = document.getElementById('dateError');
  var elDateErrT = document.getElementById('dateErrorText');

  var step1Panel    = document.getElementById('step1Panel');
  var step2Panel    = document.getElementById('step2Panel');
  var allRoomsPanel = document.getElementById('allRoomsPanel');

  var elSkeleton = document.getElementById('roomsSkeleton');
  var elGrid     = document.getElementById('roomsGrid');
  var elMeta     = document.getElementById('roomsMeta');
  var elError    = document.getElementById('roomsError');
  var elErrText  = document.getElementById('roomsErrorText');
  var elEmpty    = document.getElementById('roomsEmpty');

  var elChangeDates = document.getElementById('changeDatesBtn');

  // Step indicators
  var sI1 = document.getElementById('step1Indicator');
  var sI2 = document.getElementById('step2Indicator');
  var sI3 = document.getElementById('step3Indicator');

  // Booking modal
  var modal     = document.getElementById('bkModal');
  var elMClose  = document.getElementById('bkModalClose');
  var elMCancel = document.getElementById('bkModalCancelBtn');
  var elMConfirm= document.getElementById('bkModalConfirmBtn');
  var elMError  = document.getElementById('bkModalError');
  var elMContent= document.getElementById('bkModalContent');
  var elSuccess = document.getElementById('bkSuccessView');
  var elSuccRef = document.getElementById('bkSuccessRef');
  var elSuccDet = document.getElementById('bkSuccessDetails');
  var elSuccDone= document.getElementById('bkSuccessDone');
  var elConfLbl = document.getElementById('bkConfirmLabel');

  // Calendar modal
  var calModal    = document.getElementById('calModal');
  var calClose    = document.getElementById('calModalClose');
  var calTitle    = document.getElementById('calModalTitle');
  var calSubtitle = document.getElementById('calModalSubtitle');
  var calLoading  = document.getElementById('calLoading');
  var calContent  = document.getElementById('calContent');
  var calGrid     = document.getElementById('calGrid');
  var calMonthLbl = document.getElementById('calMonthLabel');
  var calPrevBtn  = document.getElementById('calPrevBtn');
  var calNextBtn  = document.getElementById('calNextBtn');

  var csrf    = (document.getElementById('csrfToken') || {}).value || '';
  var imgBase = (document.getElementById('imgBase') || {}).value || '';

  /* ---- State ---- */
  var currentCheckIn  = '';
  var currentCheckOut = '';
  var currentGuests   = 1;
  var pendingBooking  = null;
  var isLoadingRooms  = false;
  var isSubmitting    = false;

  // Calendar state
  var calRoomId     = null;
  var calRoomStatus = 'available'; // admin-set status
  var calBookedRanges = [];        // [{check_in, check_out}]
  var calDisplayYear  = new Date().getFullYear();
  var calDisplayMonth = new Date().getMonth(); // 0-based

  var MONTHS = ['January','February','March','April','May','June',
                'July','August','September','October','November','December'];
  var DAY_HEADERS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

  /* ---- Date helpers ---- */
  function todayStr() {
    var d = new Date();
    return d.getFullYear() + '-' +
      String(d.getMonth() + 1).padStart(2, '0') + '-' +
      String(d.getDate()).padStart(2, '0');
  }

  function formatDate(ymd) {
    if (!ymd) return '';
    var p = ymd.split('-');
    if (p.length !== 3) return ymd;
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    return months[parseInt(p[1], 10) - 1] + ' ' + parseInt(p[2], 10) + ', ' + p[0];
  }

  function calcNights(ci, co) {
    if (!ci || !co) return 0;
    return Math.round((new Date(co) - new Date(ci)) / 86400000);
  }

  function showDateError(msg) {
    elDateErrT.textContent = msg;
    elDateErr.style.display = 'flex';
  }
  function hideDateError() {
    elDateErr.style.display = 'none';
  }

  function updateNightSummary() {
    var ci = elCheckIn.value;
    var co = elCheckOut.value;
    if (!ci || !co) { elNightSum.style.display = 'none'; return; }
    var n = calcNights(ci, co);
    if (n <= 0) { elNightSum.style.display = 'none'; return; }
    elNightTxt.textContent = n + ' night' + (n === 1 ? '' : 's') + ' · ' + formatDate(ci) + ' → ' + formatDate(co);
    elNightSum.style.display = 'flex';
  }

  function validateDates() {
    var ci = elCheckIn.value;
    var co = elCheckOut.value;
    hideDateError();
    if (!ci || !co) return false;
    if (ci < todayStr()) { showDateError('Check-in date cannot be in the past.'); return false; }
    if (co <= ci)        { showDateError('Check-out must be after check-in.'); return false; }
    if (calcNights(ci, co) > 90) { showDateError('Maximum stay is 90 nights.'); return false; }
    return true;
  }

  /* ---- Guests stepper ---- */
  document.getElementById('guestsMinus').addEventListener('click', function () {
    var v = parseInt(elGuests.value, 10);
    if (v > 1) elGuests.value = v - 1;
    currentGuests = parseInt(elGuests.value, 10);
  });
  document.getElementById('guestsPlus').addEventListener('click', function () {
    var v = parseInt(elGuests.value, 10);
    if (v < 20) elGuests.value = v + 1;
    currentGuests = parseInt(elGuests.value, 10);
  });

  /* ---- Date change listeners ---- */
  elCheckIn.addEventListener('change', function () {
    if (elCheckIn.value) {
      var nextDay = new Date(elCheckIn.value);
      nextDay.setDate(nextDay.getDate() + 1);
      var minOut = nextDay.toISOString().slice(0, 10);
      elCheckOut.min = minOut;
      if (elCheckOut.value && elCheckOut.value <= elCheckIn.value) {
        elCheckOut.value = minOut;
      }
    }
    updateNightSummary();
    validateDates();
  });

  elCheckOut.addEventListener('change', function () {
    updateNightSummary();
    validateDates();
  });

  /* ---- Step management ---- */
  function setStep(n) {
    if (n === 1) {
      step1Panel.style.display    = '';
      step2Panel.style.display    = 'none';
      allRoomsPanel.style.display = '';
      sI1.className = 'booking-step is-active';
      sI2.className = 'booking-step';
      sI3.className = 'booking-step';
    } else if (n === 2) {
      step1Panel.style.display    = 'none';
      step2Panel.style.display    = '';
      allRoomsPanel.style.display = 'none';
      sI1.className = 'booking-step is-done';
      sI2.className = 'booking-step is-active';
      sI3.className = 'booking-step';
    } else if (n === 3) {
      sI1.className = 'booking-step is-done';
      sI2.className = 'booking-step is-done';
      sI3.className = 'booking-step is-active';
    }
  }

  /* ---- Availability check ---- */
  function showRoomsLoading() {
    elSkeleton.style.display = 'grid';
    elGrid.style.display     = 'none';
    elError.style.display    = 'none';
    elEmpty.style.display    = 'none';
  }
  function hideRoomsLoading() {
    elSkeleton.style.display = 'none';
  }

  function buildRoomCard(room) {
    var card = document.createElement('div');
    card.className = 'room-card' +
      (room.availability === 'occupied'    ? ' is-occupied'    : '') +
      (room.availability === 'unavailable' ? ' is-unavailable' : '');

    var availClass = 'avail--' + room.availability;

    var mediaHtml = '';
    if (room.image_filename) {
      mediaHtml = '<img src="' + imgBase + encodeURIComponent(room.image_filename) +
                  '" alt="' + escHtml(room.name) + '" loading="lazy">';
    } else {
      mediaHtml = '<span class="room-card__media-icon">' + bedIcon() + '</span>';
    }

    var amenHtml = '';
    if (room.amenities && room.amenities.length) {
      var shown = room.amenities.slice(0, 4);
      var more  = room.amenities.length - 4;
      amenHtml  = shown.map(function (a) {
        return '<span class="room-tag">' + escHtml(a) + '</span>';
      }).join('');
      if (more > 0) {
        amenHtml += '<span class="room-tag room-tag--more">+' + more + ' more</span>';
      }
      amenHtml = '<div class="room-card__amenities">' + amenHtml + '</div>';
    }

    var descHtml = room.description
      ? '<p class="room-card__desc">' + escHtml(room.description) + '</p>'
      : '';

    var actionHtml = room.availability === 'available'
      ? '<button type="button" class="btn-book" data-room-id="' + room.id + '">' +
        sendIcon() + ' Book This Room</button>'
      : '<span style="font-size:12px;color:var(--paper-faint);font-weight:600">' +
        escHtml(room.availability_label) + '</span>';

    card.innerHTML =
      '<div class="room-card__media">' +
        mediaHtml +
        '<span class="room-card__price-badge">' + escHtml(room.price_formatted) +
          '<small>/night</small></span>' +
        '<span class="room-card__avail-badge ' + availClass + '">' +
          '<span class="dot"></span>' + escHtml(room.availability_label) +
        '</span>' +
      '</div>' +
      '<div class="room-card__body">' +
        '<div class="room-card__head">' +
          '<div class="room-card__name">' + escHtml(room.name) + '</div>' +
          '<div class="room-card__type">' + escHtml(room.type) + '</div>' +
        '</div>' +
        '<div class="room-card__meta">' +
          usersIcon() +
          '<span>Up to ' + room.capacity + ' guest' + (room.capacity === 1 ? '' : 's') + '</span>' +
        '</div>' +
        amenHtml +
        descHtml +
      '</div>' +
      '<div class="room-card__footer">' +
        '<div class="room-card__total">' + escHtml(room.total_formatted) +
          '<br><small>' + room.nights + ' night' + (room.nights === 1 ? '' : 's') + '</small>' +
        '</div>' +
        actionHtml +
      '</div>';

    if (room.availability === 'available') {
      card.querySelector('.btn-book').addEventListener('click', function () {
        openBookingModal(room);
      });
    }

    return card;
  }

  function checkAvailability() {
    if (isLoadingRooms) return;
    if (!validateDates()) return;

    var ci = elCheckIn.value;
    var co = elCheckOut.value;
    var g  = parseInt(elGuests.value, 10) || 1;

    currentCheckIn  = ci;
    currentCheckOut = co;
    currentGuests   = g;

    setStep(2);
    showRoomsLoading();

    isLoadingRooms = true;
    elCheckBtn.disabled = true;

    fetch('api/bookings.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action:     'availability',
        check_in:   ci,
        check_out:  co,
        csrf_token: csrf,
      }),
    })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      isLoadingRooms = false;
      elCheckBtn.disabled = false;
      hideRoomsLoading();

      if (!data.success) {
        elErrText.textContent = data.error || 'Could not load rooms.';
        elError.style.display = 'flex';
        return;
      }

      var rooms  = data.rooms || [];
      var nights = data.nights || 0;

      elMeta.innerHTML =
        '<strong>' + rooms.length + '</strong> room' + (rooms.length === 1 ? '' : 's') +
        ' · <strong>' + nights + '</strong> night' + (nights === 1 ? '' : 's') +
        ' · ' + formatDate(ci) + ' → ' + formatDate(co);

      var availCount = rooms.filter(function (r) { return r.availability === 'available'; }).length;
      elGrid.innerHTML = '';

      if (rooms.length === 0) {
        elEmpty.style.display = 'block';
        return;
      }

      elGrid.style.display = 'grid';

      rooms.sort(function (a, b) {
        var order = { available: 0, occupied: 1, unavailable: 2 };
        return (order[a.availability] || 0) - (order[b.availability] || 0);
      });

      rooms.forEach(function (room) {
        elGrid.appendChild(buildRoomCard(room));
      });

      if (availCount === 0) {
        var notice = document.createElement('div');
        notice.className = 'api-error';
        notice.style.gridColumn = '1/-1';
        notice.innerHTML = bedIcon() + '<span>No rooms are available for these dates. Try different dates.</span>';
        elGrid.prepend(notice);
      }
    })
    .catch(function () {
      isLoadingRooms = false;
      elCheckBtn.disabled = false;
      hideRoomsLoading();
      elErrText.textContent = 'Network error. Please check your connection and try again.';
      elError.style.display = 'flex';
    });
  }

  elCheckBtn.addEventListener('click', checkAvailability);

  elChangeDates.addEventListener('click', function () {
    setStep(1);
  });

  /* ---- "Select & Check" button on room thumbnails ---- */
  document.getElementById('allRoomsGrid') && document.getElementById('allRoomsGrid').addEventListener('click', function (e) {
    var btn = e.target.closest('[data-select-room-id]');
    if (!btn) return;

    // Scroll to date picker and highlight it
    step1Panel.scrollIntoView({ behavior: 'smooth', block: 'start' });

    // Flash the date inputs
    var ci = document.getElementById('bkCheckIn');
    var co = document.getElementById('bkCheckOut');
    [ci, co].forEach(function (el) {
      el.style.transition = 'box-shadow .3s';
      el.style.boxShadow = '0 0 0 3px rgba(232,163,61,.5)';
      setTimeout(function () { el.style.boxShadow = ''; }, 1400);
    });

    if (!elCheckIn.value || !elCheckOut.value) {
      showDateError('Please set your check-in and check-out dates first, then click Check Availability.');
    }
  });

  /* ============================================================
     CALENDAR MODAL
     ============================================================ */

  /* Open calendar when "View Calendar" button is clicked */
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('[data-cal-room-id]');
    if (!btn) return;
    e.stopPropagation();

    var roomId   = parseInt(btn.getAttribute('data-cal-room-id'), 10);
    var roomName = btn.getAttribute('data-cal-room-name') || 'Room';
    var roomType = btn.getAttribute('data-cal-room-type') || '';

    // Find the admin status from the card's data attribute
    var card = btn.closest('[data-room-status]');
    calRoomStatus = card ? card.getAttribute('data-room-status') : 'available';

    openCalModal(roomId, roomName, roomType);
  });

  function openCalModal(roomId, roomName, roomType) {
    calRoomId = roomId;

    calTitle.textContent    = roomName;
    calSubtitle.textContent = roomType ? roomType + ' · Booking Calendar' : 'Booking Calendar';

    // Reset to current month
    var now = new Date();
    calDisplayYear  = now.getFullYear();
    calDisplayMonth = now.getMonth();

    // Show modal in loading state
    calLoading.style.display  = 'flex';
    calContent.style.display  = 'none';

    calModal.showModal ? calModal.showModal() : calModal.setAttribute('open', '');

    // Fetch calendar data
    fetchCalendarData(roomId);
  }

  function fetchCalendarData(roomId) {
    fetch('api/bookings.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action:     'room_calendar',
        room_id:    roomId,
        csrf_token: csrf,
      }),
    })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      calLoading.style.display = 'none';

      if (!data.success) {
        calContent.style.display = 'block';
        calGrid.innerHTML = '<p style="color:var(--danger);text-align:center;padding:20px 0">' +
          escHtml(data.error || 'Could not load calendar.') + '</p>';
        calMonthLbl.textContent = '';
        return;
      }

      calBookedRanges = data.bookings || [];
      calRoomStatus   = data.room_status || calRoomStatus;

      calContent.style.display = 'block';
      renderCalendar();
    })
    .catch(function () {
      calLoading.style.display = 'none';
      calContent.style.display = 'block';
      calGrid.innerHTML = '<p style="color:var(--danger);text-align:center;padding:20px 0">Network error. Please try again.</p>';
      calMonthLbl.textContent = '';
    });
  }

  function renderCalendar() {
    var year  = calDisplayYear;
    var month = calDisplayMonth;

    calMonthLbl.textContent = MONTHS[month] + ' ' + year;

    var todayIso = todayStr();

    // Prev button: disable if we're at current month
    var now = new Date();
    var isPastOrCurrent = (year < now.getFullYear()) ||
      (year === now.getFullYear() && month <= now.getMonth());
    calPrevBtn.disabled = isPastOrCurrent;

    // Build grid
    calGrid.innerHTML = '';

    // Day headers
    DAY_HEADERS.forEach(function (d) {
      var el = document.createElement('div');
      el.className = 'cal-day-header';
      el.textContent = d;
      calGrid.appendChild(el);
    });

    // First day of month
    var firstDay = new Date(year, month, 1).getDay(); // 0=Sun
    var daysInMonth = new Date(year, month + 1, 0).getDate();

    // Empty cells before first day
    for (var i = 0; i < firstDay; i++) {
      var empty = document.createElement('div');
      empty.className = 'cal-day cal-day--empty';
      calGrid.appendChild(empty);
    }

    // Day cells
    for (var day = 1; day <= daysInMonth; day++) {
      var isoDate = year + '-' +
        String(month + 1).padStart(2, '0') + '-' +
        String(day).padStart(2, '0');

      var el = document.createElement('div');
      el.className = 'cal-day';
      el.textContent = day;

      var isPast = isoDate < todayIso;
      var isToday = isoDate === todayIso;

      if (isToday) {
        el.classList.add('cal-day--today');
      }

      if (isPast) {
        el.classList.add('cal-day--past');
      } else {
        // Determine day status
        var dayStatus = getDayStatus(isoDate);
        el.classList.add('cal-day--' + dayStatus);
        el.title = getDayTitle(dayStatus, isoDate);
      }

      calGrid.appendChild(el);
    }
  }

  /**
   * Returns the calendar display class for a given ISO date.
   * Priority: maintenance > unavailable > booked > available
   */
  function getDayStatus(isoDate) {
    // If admin has marked the whole room as maintenance or unavailable
    if (calRoomStatus === 'maintenance') return 'maintenance';
    if (calRoomStatus === 'unavailable') return 'unavailable';

    // Check booked ranges (check_in inclusive, check_out exclusive — guest leaves that morning)
    for (var i = 0; i < calBookedRanges.length; i++) {
      var b = calBookedRanges[i];
      if (isoDate >= b.check_in && isoDate < b.check_out) {
        return 'booked';
      }
    }

    return 'available';
  }

  function getDayTitle(status, isoDate) {
    switch (status) {
      case 'booked':      return 'Booked — ' + isoDate;
      case 'maintenance': return 'Under maintenance';
      case 'unavailable': return 'Not available';
      default:            return 'Available — ' + isoDate;
    }
  }

  /* Month navigation */
  calPrevBtn.addEventListener('click', function () {
    calDisplayMonth--;
    if (calDisplayMonth < 0) { calDisplayMonth = 11; calDisplayYear--; }
    renderCalendar();
  });

  calNextBtn.addEventListener('click', function () {
    calDisplayMonth++;
    if (calDisplayMonth > 11) { calDisplayMonth = 0; calDisplayYear++; }
    renderCalendar();
  });

  /* Close calendar modal */
  calClose.addEventListener('click', closeCalModal);
  calModal.addEventListener('click', function (e) {
    var rect = calModal.getBoundingClientRect();
    if (e.clientY < rect.top || e.clientY > rect.bottom ||
        e.clientX < rect.left || e.clientX > rect.right) {
      closeCalModal();
    }
  });
  calModal.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeCalModal();
  });

  function closeCalModal() {
    if (calModal.close) calModal.close();
    else calModal.removeAttribute('open');
    calBookedRanges = [];
    calRoomId = null;
  }

  /* ============================================================
     BOOKING MODAL
     ============================================================ */

  function openBookingModal(room) {
    pendingBooking = {
      room:     room,
      checkIn:  currentCheckIn,
      checkOut: currentCheckOut,
      guests:   currentGuests,
      nights:   room.nights,
    };

    setStep(3);

    document.getElementById('bkModalRoomName').textContent = room.name;
    document.getElementById('bkModalRoomType').textContent = room.type;

    var imgWrap = document.getElementById('bkModalImg');
    imgWrap.innerHTML = '';
    if (room.image_filename) {
      var img = document.createElement('img');
      img.src = imgBase + encodeURIComponent(room.image_filename);
      img.alt = room.name;
      imgWrap.appendChild(img);
    } else {
      imgWrap.innerHTML = bedIconLarge();
    }

    document.getElementById('bkDetailCheckIn').textContent  = formatDate(currentCheckIn);
    document.getElementById('bkDetailCheckOut').textContent = formatDate(currentCheckOut);
    document.getElementById('bkDetailNights').textContent   = room.nights + ' night' + (room.nights === 1 ? '' : 's');
    document.getElementById('bkDetailGuests').textContent   = currentGuests + ' guest' + (currentGuests === 1 ? '' : 's');
    document.getElementById('bkDetailRate').textContent     = room.price_formatted + '/night';
    document.getElementById('bkDetailTotal').textContent    = '₱' + formatNumber((room.price * room.nights));

    document.getElementById('bkNotes').value = '';
    elMError.textContent = '';
    elConfLbl.textContent = 'Confirm Booking';
    elMConfirm.disabled = false;

    elMContent.style.display = '';
    elSuccess.classList.remove('is-visible');

    modal.showModal ? modal.showModal() : modal.setAttribute('open', '');
  }

  function closeModal() {
    if (modal.close) modal.close();
    else modal.removeAttribute('open');
    if (pendingBooking) setStep(2);
  }

  elMClose.addEventListener('click', closeModal);
  elMCancel.addEventListener('click', closeModal);

  modal.addEventListener('click', function (e) {
    var rect = modal.getBoundingClientRect();
    if (e.clientY < rect.top || e.clientY > rect.bottom ||
        e.clientX < rect.left || e.clientX > rect.right) { closeModal(); }
  });

  modal.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { closeModal(); }
  });

  /* ---- Confirm booking ---- */
  elMConfirm.addEventListener('click', function () {
    if (!pendingBooking || isSubmitting) return;

    elMError.textContent = '';
    isSubmitting = true;
    elMConfirm.disabled = true;
    elConfLbl.textContent = 'Booking…';

    var notes = (document.getElementById('bkNotes').value || '').trim();

    fetch('api/bookings.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action:           'book',
        check_in:         pendingBooking.checkIn,
        check_out:        pendingBooking.checkOut,
        accommodation_id: pendingBooking.room.id,
        guests_count:     pendingBooking.guests,
        notes:            notes,
        csrf_token:       csrf,
      }),
    })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      isSubmitting = false;

      if (!data.success) {
        elMError.textContent = data.error || 'Booking failed. Please try again.';
        elMConfirm.disabled = false;
        elConfLbl.textContent = 'Confirm Booking';
        return;
      }

      elMContent.style.display = 'none';
      elSuccess.classList.add('is-visible');
      elSuccRef.textContent = data.reference;

      var det = formatDate(data.check_in) + ' → ' + formatDate(data.check_out) +
                ' · ' + data.room_name +
                ' · ' + data.total_formatted;
      elSuccDet.textContent = det;

      injectNewBooking(data);
    })
    .catch(function () {
      isSubmitting = false;
      elMError.textContent = 'Network error. Please try again.';
      elMConfirm.disabled = false;
      elConfLbl.textContent = 'Confirm Booking';
    });
  });

  elSuccDone.addEventListener('click', function () {
    closeModal();
    document.querySelector('.bk-list') &&
      document.querySelector('.bk-list').scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  /* ---- Inject new booking row ---- */
  function injectNewBooking(data) {
    var container = document.querySelector('.bk-list');
    if (!container) {
      var panels = document.querySelectorAll('.panel');
      var panel  = panels[panels.length - 1];
      if (!panel) return;
      var emptyState = panel.querySelector('.empty-state');
      if (emptyState) emptyState.remove();
      container = document.createElement('div');
      container.className = 'bk-list';
      panel.appendChild(container);
    }

    var nights = data.nights || 1;
    var guests = data.guests_count || 1;

    var art = document.createElement('article');
    art.className = 'bk-item';
    art.innerHTML =
      '<div class="bk-item__ref">' + escHtml(data.reference) + '</div>' +
      '<div class="bk-item__body">' +
        '<div class="bk-item__room">' + escHtml(data.room_name) + '</div>' +
        '<div class="bk-item__dates">' + formatDate(data.check_in) + ' → ' + formatDate(data.check_out) + '</div>' +
        '<div class="bk-item__meta">' + nights + ' night' + (nights === 1 ? '' : 's') + ' · ' +
          guests + ' guest' + (guests === 1 ? '' : 's') + '</div>' +
      '</div>' +
      '<div class="bk-item__right">' +
        '<span class="bk-item__amount">₱' + formatNumber(data.total_amount) + '</span>' +
        '<span class="badge badge--green">Confirmed</span>' +
      '</div>';

    container.insertBefore(art, container.firstChild);
  }

  /* ---- Utility ---- */
  function escHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function formatNumber(n) {
    return Number(n).toLocaleString('en-PH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function bedIcon() {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" class="icon" style="width:100%;height:100%;object-fit:contain"><path d="M2 4v16"/><path d="M2 8h18a2 2 0 0 1 2 2v10"/><path d="M2 17h20"/><path d="M6 8v9"/></svg>';
  }

  function bedIconLarge() {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="width:26px;height:26px;color:var(--paper-faint)"><path d="M2 4v16"/><path d="M2 8h18a2 2 0 0 1 2 2v10"/><path d="M2 17h20"/><path d="M6 8v9"/></svg>';
  }

  function sendIcon() {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="width:14px;height:14px;display:inline-block;vertical-align:middle"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>';
  }

  function usersIcon() {
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false" style="width:14px;height:14px;flex-shrink:0"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>';
  }

})();
</script>
