<?php
/**
 * api/accommodations-public.php
 * -----------------------------------------------------------------------
 * Public (no auth required) JSON endpoint.
 * Returns every accommodation whose status is 'available', ordered by
 * name. Used by the landing-page booking strip to populate the
 * Accommodation <select> with exactly what the admin has set up —
 * no hard-coded room names in the HTML.
 *
 * Output shape (200 OK):
 * {
 *   "success": true,
 *   "rooms": [
 *     { "id": 1, "name": "Barkada Room", "capacity": 4, "price": "2000.00", "status": "available" },
 *     ...
 *   ]
 * }
 *
 * On any error returns { "success": false, "rooms": [] } so the
 * landing page can fall back gracefully (keep the strip hidden / static).
 *
 * CORS: same-origin only — no Access-Control-Allow-Origin header.
 * -----------------------------------------------------------------------
 */

header('Content-Type: application/json; charset=utf-8');
header('X-Robots-Tag: noindex');
// Short cache — room list doesn't change often, 30 s is fine.
header('Cache-Control: public, max-age=30');

function pub_fail(): never
{
    echo json_encode(['success' => false, 'rooms' => []]);
    exit;
}

try {
    require_once __DIR__ . '/../includes/db.php';
} catch (Throwable $e) {
    pub_fail();
}

try {
    $pdo = bienmarko_db();

    // Ensure table exists (same defensive pattern as featured-rooms.php)
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `accommodations` (
            `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
            `name` VARCHAR(150) NOT NULL,
            `type` VARCHAR(100) NOT NULL DEFAULT '',
            `capacity` SMALLINT UNSIGNED NOT NULL DEFAULT 1,
            `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
            `status` ENUM('available','booked','unavailable','maintenance') NOT NULL DEFAULT 'available',
            `description` TEXT NULL,
            `amenities` TEXT NULL,
            `image_filename` VARCHAR(255) NULL,
            `is_featured` TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    // Return all rooms (any status) so the user can see what exists;
    // availability conflict detection happens in book.php.
    // We expose id, name, capacity, price, status — enough for the
    // booking strip select and for book.php to pre-select.
    $stmt = $pdo->query(
        "SELECT
            `id`,
            `name`,
            `capacity`,
            `price`,
            `status`
         FROM `accommodations`
         ORDER BY `name` ASC"
    );

    $rows  = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $rooms = [];

    foreach ($rows as $row) {
        $rooms[] = [
            'id'       => (int) $row['id'],
            'name'     => $row['name'],
            'capacity' => (int) $row['capacity'],
            'price'    => $row['price'],   // string, JS formats it
            'status'   => $row['status'],
        ];
    }

    echo json_encode(['success' => true, 'rooms' => $rooms], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    pub_fail();
}
